package com.example.zd2_1up

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import com.example.zd2_1up.databinding.ActivityMainScreenBinding

class MainScreen : Activity() {

    private lateinit var binding: ActivityMainScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val speak=findViewById<ImageButton>(R.id.discussionsImageView)
        val speak2=findViewById<ImageButton>(R.id.setsImageView)
        val favorit=findViewById<ImageButton>(R.id.favouritesImageView)
        speak.setOnClickListener{
            val intent= Intent(this,ChatListScreen::class.java)
            startActivity(intent)
        }
        speak2.setOnClickListener {
            val intent= Intent(this, ChatListScreen::class.java)
            startActivity(intent)
        }
        favorit.setOnClickListener {
            val intent= Intent(this, MoviesScreen::class.java)
            startActivity(intent)
        }
    }
}