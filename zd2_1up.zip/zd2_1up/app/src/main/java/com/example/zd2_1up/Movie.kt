package com.example.zd2_1up

data class Movie(
    val Title: String,
    val Poster: String
)
