package com.example.zd2_1up

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import com.example.zd2_1up.databinding.ActivityMainBinding
@SuppressLint("CustomSplashScreen")
class MainActivity : Activity() {

    private lateinit var binding: ActivityMainBinding
    private val splashDelay: Long = 1000
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setContentView(R.layout.activity_main)
        Handler().postDelayed({
            val intent = Intent(this@MainActivity, SignInScreen::class.java)
            startActivity(intent)
            finish()
        }, splashDelay)

    }
}