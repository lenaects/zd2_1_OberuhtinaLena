package com.example.zd2_1up

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import com.example.zd2_1up.databinding.ActivityMoviesScreenBinding
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MoviesScreen : Activity() {
    private val apiKey = "43181e24"
    private val omdbApiService: OmdbApiService

    private lateinit var img1: ImageView
    private lateinit var img2: ImageView
    private lateinit var img3: ImageView

    private lateinit var txt1: TextView
    private lateinit var txt2: TextView
    private lateinit var txt3: TextView

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://www.omdbapi.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        omdbApiService = retrofit.create(OmdbApiService::class.java)
    }

    private lateinit var binding: ActivityMoviesScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMoviesScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        img1 = findViewById(R.id.rectangleImageView1)
        txt1 = findViewById(R.id.text1)

        img2 = findViewById(R.id.rectangleImageView2)
        txt2 = findViewById(R.id.text2)

        img3 = findViewById(R.id.rectangleImageView3)
        txt3 = findViewById(R.id.text3)

        vivod("Witcher", img1, txt1)
        vivod("Jessica Jones", img2, txt2)
        vivod("Magicians", img3, txt3)
    }

    private fun vivod(nameFilm: String, img: ImageView, txt: TextView) {
        val call = omdbApiService.getMovieDetails(apiKey, nameFilm)

        call.enqueue(object :Callback<Movie> {
            override fun onResponse(call: Call<Movie>, response: Response<Movie>) {
                if (response.isSuccessful) {
                    val movie = response.body()
                    if (movie != null) {
                        // Ваш код для обработки данных о фильме, например:
                        val title = movie.Title
                        val posterUrl = movie.Poster

                        // Теперь у вас есть название фильма и URL постера
                        Log.d("MovieDetails", "Title: $title, Poster URL: $posterUrl")

                        Picasso.get().load(posterUrl).into(img)
                        txt.text = title

                    }
                }
            }

            override fun onFailure(call: Call<Movie>, t: Throwable) {
                // Обработка ошибок
                Log.e("MovieDetails", "Failed to retrieve movie details", t)
            }
        })
    }
}