package com.example.zd2_1up

import android.app.Activity
import android.os.Bundle
import com.example.zd2_1up.databinding.ActivityChatListScreenBinding

class ChatListScreen : Activity() {

    private lateinit var binding: ActivityChatListScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityChatListScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }
}